#include "StdAfx.h"

#include "SymProxyOptions.h"

// Installation:
// Rename the original symproxy.dll to symproxy.orig.dll
// Rename the original symsrv.dll to symsrv.orig.dll
// Compiling this project will generate SymSrv.dll
// Change the old symproxy.dll ISAPI registration to point to the new SymSrv.dll file

// Test:
// The simplest way to test is to run IIS in debug mode
// Make sure you run VC elevated
// C:\Windows\System32\inetsrv\w3wp.exe /debug

// Global symbol proxy object and module handle
CSymbolProxy g_SymbolProxy;
HMODULE g_hModule = NULL;

// ISAPI filter exports
BOOL WINAPI GetFilterVersion(HTTP_FILTER_VERSION *pVer)
{
    // Create the symbol proxy object
    if (g_SymbolProxy.Create() == false)
    {
        return FALSE;
    }

    // Call the symbol proxy
    return g_SymbolProxy.GetFilterVersion(pVer);
}

DWORD WINAPI HttpFilterProc(HTTP_FILTER_CONTEXT *pFC, DWORD dwNotificationType, VOID *pNotification)
{
    // Call the symbol proxy
    return g_SymbolProxy.HttpFilterProc(pFC, dwNotificationType, pNotification);
}

BOOL WINAPI TerminateFilter(DWORD dwFlags)
{
    // Destroy the symbol proxy object
    g_SymbolProxy.Destroy();

    return TRUE;
}


// Symbol server exports
BOOL WINAPI SymbolServerSetOptions(UINT_PTR uOptions, ULONG64 uData)
{
    // Call the symbol proxy
    return g_SymbolProxy.SymbolServerSetOptions(uOptions, uData);
}

BOOL WINAPI SymbolServerByIndex(PCSTR szOption1, PCSTR szOption2, PCSTR szOption3, PSTR szOut)
{
    // Call the symbol proxy
    return g_SymbolProxy.SymbolServerByIndex(szOption1, szOption2, szOption3, szOut);
}


const LPCTSTR CSymbolProxy::m_szSymbolProxyDll = _T("symproxy.orig");
const LPCTSTR CSymbolProxy::m_szSymbolServerDll = _T("symsrv.orig");

CSymbolProxy::CSymbolProxy() throw() :
    m_hSymbolProxy(NULL),
    m_hSymbolServer(NULL),
    m_pGetFilterVersionProc(NULL),
    m_pHttpFilterProc(NULL),
    m_pSymbolServerSetOptionsProc(NULL),
    m_pSymbolServerByIndexProc(NULL),
    m_pSymbolServerByIndexWProc(NULL),
    m_pFilterUrlMap(NULL)
{
}

CSymbolProxy::~CSymbolProxy() throw()
{
    Destroy();
}

bool CSymbolProxy::Create() throw()
{
    // Destroy
    Destroy();

    bool bRet = false;
    for (;;)
    {
        // Initialize the critical section
        InitializeCriticalSection(&m_CriticalSection);

        // We need to load the original DLLs from the same directory as this DLL
        // Get this DLLs directory
        PathInfo thisPath;
        DWORD dwErr = GetModuleFileName(g_hModule, thisPath.szPath, _countof(thisPath.szPath));
        if (dwErr == 0 ||
            (dwErr == _countof(thisPath.szPath) && GetLastError() == ERROR_INSUFFICIENT_BUFFER))
        {
            break;
        }
        if (_tsplitpath_s(thisPath.szPath, thisPath.szDrive, thisPath.szDirectory, thisPath.szFileName, thisPath.szExtension) != 0)
        {
            break;
        }

        // Build new paths
        PathInfo symbolProxyPath;
        PathInfo symbolServerPath;
        if (_tmakepath_s(symbolProxyPath.szPath, thisPath.szDrive, thisPath.szDirectory, m_szSymbolProxyDll, _T(".dll")) != 0 ||
            _tmakepath_s(symbolServerPath.szPath, thisPath.szDrive, thisPath.szDirectory, m_szSymbolServerDll, _T(".dll")) != 0)
        {
            break;
        }

        // Load symbol proxy and symbol server DLLs
        m_hSymbolProxy = LoadLibrary(symbolProxyPath.szPath);
        m_hSymbolServer = LoadLibrary(symbolServerPath.szPath);
        if (m_hSymbolProxy == NULL ||
            m_hSymbolServer == NULL)
        {
            break;
        }

        // Get function pointers
        m_pGetFilterVersionProc = reinterpret_cast<PGETFILTERVERSIONPROC>(GetProcAddress(m_hSymbolProxy, "GetFilterVersion"));
        m_pHttpFilterProc = reinterpret_cast<PHTTPFILTERPROC>(GetProcAddress(m_hSymbolProxy, "HttpFilterProc"));
        m_pSymbolServerSetOptionsProc = reinterpret_cast<PSYMBOLSERVERSETOPTIONSPROC>(GetProcAddress(m_hSymbolServer, "SymbolServerSetOptions"));
        m_pSymbolServerByIndexProc = reinterpret_cast<PSYMBOLSERVERBYINDEXPROC>(GetProcAddress(m_hSymbolServer, "SymbolServerByIndex"));
        m_pSymbolServerByIndexWProc = reinterpret_cast<PSYMBOLSERVERBYINDEXPROC>(GetProcAddress(m_hSymbolServer, "SymbolServerByIndexW"));
        if (m_pGetFilterVersionProc == NULL ||
            m_pHttpFilterProc == NULL ||
            m_pSymbolServerSetOptionsProc == NULL ||
            m_pSymbolServerByIndexProc == NULL ||
            m_pSymbolServerByIndexWProc == NULL)
        {
            break;
        }

        // Done
        bRet = true;
        break;
    }
    if (bRet == false)
    {
        Destroy();
    }
    return bRet;
}

bool CSymbolProxy::Destroy() throw()
{
    // Unload DLLs
    if (m_hSymbolProxy != NULL)
    {
        FreeLibrary(m_hSymbolProxy);
        m_hSymbolProxy = NULL;
    }
    if (m_hSymbolServer != NULL)
    {
        FreeLibrary(m_hSymbolServer);
        m_hSymbolServer = NULL;
    }

    // Clear funtion pointers
    m_pGetFilterVersionProc = NULL;
    m_pHttpFilterProc = NULL;
    m_pSymbolServerSetOptionsProc = NULL;
    m_pSymbolServerByIndexProc = NULL;
    m_pSymbolServerByIndexWProc = NULL;

    m_pFilterUrlMap = NULL;

    // Destroy the critical section
    DeleteCriticalSection(&m_CriticalSection);

    return true;
}

BOOL CSymbolProxy::GetFilterVersion(HTTP_FILTER_VERSION *pVer) throw()
{
    // Validate
    if (m_pGetFilterVersionProc == NULL)
    {
        return FALSE;
    }

    // Symbol proxy sets pVer->dwFlags:
    //                          0x00081203 
    // SF_NOTIFY_ORDER_HIGH     0x00080000
    // SF_NOTIFY_URL_MAP        0x00001000
    // SF_NOTIFY_LOG            0x00000200
    // SF_NOTIFY_NONSECURE_PORT 0x00000002
    // SF_NOTIFY_SECURE_PORT    0x00000001

    // Call the symbol proxy
    return m_pGetFilterVersionProc(pVer);
}

DWORD CSymbolProxy::HttpFilterProc(HTTP_FILTER_CONTEXT *pFC, DWORD dwNotificationType, VOID *pNotification) throw()
{
    // Validate
    if (m_pHttpFilterProc == NULL)
    {
        return SF_STATUS_REQ_NEXT_NOTIFICATION;
    }

    // The symbol proxy only processes dwNotificationType == SF_NOTIFY_URL_MAP 0x00001000
    // This means that pNotification = PHTTP_FILTER_URL_MAP
    DWORD dwRet = SF_STATUS_REQ_NEXT_NOTIFICATION;
    if (dwNotificationType == SF_NOTIFY_URL_MAP)
    {
        // We have to lock at this point to make sure that m_pFilterUrlMap stays valid
        EnterCriticalSection(&m_CriticalSection);
        {
            m_pFilterUrlMap = reinterpret_cast<PHTTP_FILTER_URL_MAP>(pNotification);
            dwRet = m_pHttpFilterProc(pFC, dwNotificationType, pNotification);
            m_pFilterUrlMap = NULL;
        }
        LeaveCriticalSection(&m_CriticalSection);
    }

    return dwRet;
}

BOOL CSymbolProxy::SymbolServerSetOptions(UINT_PTR uOptions, ULONG64 uData) throw()
{
    // Validate
    if (m_pSymbolServerSetOptionsProc == NULL)
    {
        return FALSE;
    }

    // Options set by symbol proxy:
    // SSRVOPT_UNATTENDED 0x00000020
    // SSRVOPT_SERVICE    0x00100000
    // SSRVOPT_CALLBACK   0x00000001
    // SSRVOPT_TRACE      0x00000400
    // SSRVOPT_PROXY      0x00001000

    // The MSDN documentation states that SSRVOPT_SERVICE is deprecated
    // If the SSRVOPT_SERVICE option is set, the 6.11 version of SymSrv.dll fails to download 
    // compressed symbols from the Microsoft Symbol Server, by not setting the option, 6.11 works fine
    if (uOptions == SSRVOPT_SERVICE)
    {
        return TRUE;
    }

    // Call the symbol proxy
    return m_pSymbolServerSetOptionsProc(uOptions, uData);
}

BOOL CSymbolProxy::SymbolServerByIndex(PCSTR szOption1, PCSTR szOption2, PCSTR szOption3, PSTR szOut) throw()
{
    // Validate
    if (m_pSymbolServerByIndexProc == NULL ||
        m_pFilterUrlMap == NULL)
    {
        return FALSE;
    }

    // The 6.11 version of SymProxy.dll makes the entire URI lowercase before processing it, and this breaks the 
    // Mozilla and Google symbol servers that are running on case sensitive (Linux) web servers
    // We have to fix the case by matching the original URL request and manually extractign the case correct values

    // Input:
    // m_pFilterUrlMap->pszURL = "/symbols/ch/chrome_exe.pdb/A931F873616F40A4972373FAD37D562D1/chrome_exe.pdb"
    // m_pFilterUrlMap->pszPhysicalPath = "C:\inetpub\Symbols\chrome_exe.pdb\A931F873616F40A4972373FAD37D562D1\chrome_exe.pdb"
    // szOption1 = "c:\inetpub\symbols*http://build.chromium.org/buildbot/symsrv"
    // szOption2 = "chrome_exe.pdb"
    // szOption3 = "a931f873616f40a4972373fad37d562d1"

    // Desired output:
    // szOption3 = "A931F873616F40A4972373FAD37D562D1"

    // The call stack should now be:
    // CSymbolProxy::HttpFilterProc(), this locked the m_CriticalSection, and saved m_pFilterUrlMap
    // Then the real symbol proxy m_pHttpFilterProc was called
    // That in turn calls CSymbolProxy::SymbolServerByIndex
    // And we will call the real symbol server m_pSymbolServerByIndexProc

    // I can't find documentation for SymbolServerByIndex, but the parameters appear to be as follows:
    // szOption1: The symbol server path
    // E.g. c:\inetpub\symbols*http://build.chromium.org/buildbot/symsrv
    // szOption2: The file being searched for
    // E.g. chrome_exe.pdb
    // szOptions3: The file identifier
    // E.g. a931f873616f40a4972373fad37d562d1

    BOOL bRet = FALSE;
    try
    {
        for (;;)
        {
            // The symbol proxy and ISAPI provide paths in MBCS, we code to T but prefer to work in UNICODE
            // SymSrv.dll does have UNICODE xxxW exports, but SymProxy.dll only uses the MBCS exports
            // SymSrv.dll, and any Windows API's, will convert the MBCS input to UNICODE then call the UNICODE xxxW function
            // We would prefer xxxW all the way to avoid the multiple string ocnversions
            ATL::CAtlString sPhysicalPath(m_pFilterUrlMap->pszPhysicalPath);

            // Split the physical path
            PathInfo physicalPath;
            if (_tsplitpath_s(sPhysicalPath, 
                              physicalPath.szDrive, 
                              physicalPath.szDirectory, 
                              physicalPath.szFileName, 
                              physicalPath.szExtension) != 0)
            {
                break;
            }

            // Build the full filename, use the path buffer for storage
            if (_tcscpy_s(physicalPath.szPath, physicalPath.szFileName) != 0 ||
                _tcscat_s(physicalPath.szPath, physicalPath.szExtension) != 0)
            {
                break;
            }
            // The filename will be something like "chrome_exe.pdb"

            // Split the identifier from the directory
            // The directory will look like "\inetpub\Symbols\chrome_exe.pdb\A931F873616F40A4972373FAD37D562D1\"
            // Start by removing the trailing '\'
            ATL::CAtlString sDirectory(physicalPath.szDirectory);
            sDirectory.TrimRight(_T('\\'));
            // The string will now look something like "\inetpub\Symbols\chrome_exe.pdb\A931F873616F40A4972373FAD37D562D1"

            // Find the last '\'
            int nPos = 0;
            int nLastPos = 0;
            for (;;)
            {
                // Find the next '\'
                nPos = sDirectory.Find(_T('\\'), nLastPos);
                if (nPos == -1)
                {
                    break;
                }
                nLastPos = nPos + 1;
            }
            if (nLastPos == 0)
            {
                // Not found
                break;
            }

            // Trim the directory at the last '\'
            sDirectory = sDirectory.Mid(nLastPos);
            // We now have the identifier, something like "A931F873616F40A4972373FAD37D562D1"

            // We are not changing the symbol server path
            // The case is maintained correctly as entered in the registry
            
            // Set the case corrected file name
            ATL::CAtlStringA sOption2(physicalPath.szPath);
            szOption2 = sOption2;

            // Set the case corrected identifier
            ATL::CAtlStringA sOption3(sDirectory);
            szOption3 = sOption3;

            // Call the symbol proxy
            bRet = m_pSymbolServerByIndexProc(szOption1, szOption2, szOption3, szOut);
            break;
        }
    }
    // We use CStrings, so we need to handle exceptions
    catch (ATL::CAtlException &)
    {
        bRet = false;
    }
    return bRet;
}


#pragma once

#include <httpfilt.h>
#include <dbghelp.h>

// ISAPI filter exports are declared in httpfilt.h
// BOOL WINAPI GetFilterVersion(HTTP_FILTER_VERSION *pVer);
// DWORD WINAPI HttpFilterProc(HTTP_FILTER_CONTEXT *pFC, DWORD dwNotificationType, VOID *pNotification);
// BOOL WINAPI TerminateFilter(DWORD dwFlags);
typedef BOOL (WINAPI *PGETFILTERVERSIONPROC)(HTTP_FILTER_VERSION *);
typedef DWORD (WINAPI *PHTTPFILTERPROC)(HTTP_FILTER_CONTEXT *, DWORD, VOID *);
typedef BOOL (WINAPI *PTERMINATEFILTERPROC)(DWORD);


// Exports used by symbol proxy from symbol server DLL
// The function pointers are dclared in dbghelp.h 
// typedef BOOL (WINAPI *PSYMBOLSERVERSETOPTIONSPROC)(UINT_PTR, ULONG64);
// typedef BOOL (WINAPI *PSYMBOLSERVERBYINDEXPROC)(PCSTR, PCSTR, PCSTR, PSTR);
// typedef BOOL (WINAPI *PSYMBOLSERVERBYINDEXPROCW)(PCWSTR, PCWSTR, PCWSTR, PWSTR);
extern "C"
{
    BOOL WINAPI SymbolServerSetOptions(UINT_PTR uOptions, ULONG64 uData);
    BOOL WINAPI SymbolServerByIndex(PCSTR szOption1, PCSTR szOption2, PCSTR szOption3, PSTR szOut);
    BOOL WINAPI SymbolServerByIndexW(PCWSTR szOption1, PCWSTR szOption2, PCWSTR szOption3, PWSTR szOut);
}

class CSymbolProxy
{
public:
    CSymbolProxy() throw();
    ~CSymbolProxy() throw();

private:
    CSymbolProxy(const CSymbolProxy&) throw();
    CSymbolProxy& operator =(const CSymbolProxy&) throw();

public:
    bool Create() throw();
    bool Destroy() throw();

public:
    BOOL GetFilterVersion(HTTP_FILTER_VERSION *pVer) throw();
    DWORD HttpFilterProc(HTTP_FILTER_CONTEXT *pFC, DWORD dwNotificationType, VOID *pNotification) throw();
    BOOL SymbolServerSetOptions(UINT_PTR uOptions, ULONG64 uData) throw();
    BOOL SymbolServerByIndex(PCSTR szOption1, PCSTR szOption2, PCSTR szOption3, PSTR szOut) throw();

protected:
    struct PathInfo
    {
        PathInfo() throw()
        {
            szPath[0] = NULL;
            szDrive[0] = NULL;
            szDirectory[0] = NULL;
            szFileName[0] = NULL;
            szExtension[0] = NULL;
        }
        TCHAR szPath[_MAX_PATH];
        TCHAR szDrive[_MAX_DRIVE];
        TCHAR szDirectory[_MAX_DIR];
        TCHAR szFileName[_MAX_FNAME];
        TCHAR szExtension[_MAX_EXT];
    };

protected:
    PGETFILTERVERSIONPROC m_pGetFilterVersionProc;
    PHTTPFILTERPROC m_pHttpFilterProc;
    // The symbol proxy does not implement a terminate filter
    // PTERMINATEFILTERPROC m_pTerminateFilterProc;
    PSYMBOLSERVERSETOPTIONSPROC m_pSymbolServerSetOptionsProc;
    PSYMBOLSERVERBYINDEXPROC m_pSymbolServerByIndexProc;
    PSYMBOLSERVERBYINDEXPROC m_pSymbolServerByIndexWProc;

protected:
    HMODULE m_hSymbolProxy;
    HMODULE m_hSymbolServer;
    CRITICAL_SECTION m_CriticalSection;

protected:
    PHTTP_FILTER_URL_MAP m_pFilterUrlMap;

protected:
    static const LPCTSTR m_szSymbolProxyDll;
    static const LPCTSTR m_szSymbolServerDll;
};

extern CSymbolProxy g_SymbolProxy;
extern HMODULE g_hModule;

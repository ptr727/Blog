#pragma once

#define WINVER 0x0600
#define _WIN32_WINNT 0x0600
#define _WIN32_WINDOWS 0x0410
#define _WIN32_IE 0x0700

#define WIN32_LEAN_AND_MEAN
#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS
#define _ATL_NO_AUTOMATIC_NAMEPSACE

#include <windows.h>
#include <atlbase.h>
#include <atlstr.h>
#include <httpext.h>

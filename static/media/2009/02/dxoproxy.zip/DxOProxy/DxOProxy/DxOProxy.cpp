#include "StdAfx.h"

#include "DxOProxy.h"

int APIENTRY _tWinMain(HINSTANCE hInstance,
                       HINSTANCE hPrevInstance,
                       LPTSTR lpCmdLine,
                       int nCmdShow)
{
	UNREFERENCED_PARAMETER(hInstance);
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(nCmdShow);

    // Disclaimer ! very limited error handling !

    // Read the DxO install path from the registry
    CRegKey regKey;
    ULONG nCount(MAX_PATH);
    CString sInstallPath;
    if (regKey.Open(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\DxOLabs\\DXOOpticsProv5"), KEY_READ) != ERROR_SUCCESS ||
        regKey.QueryStringValue(_T("InstallPath"), sInstallPath.GetBuffer(nCount), &nCount) !=  ERROR_SUCCESS) 
    {
        return -1;
    }
    sInstallPath.ReleaseBuffer();

    // Build the full path
    CString sFullPath(_T("\""));
    sFullPath.Append(sInstallPath);
    sFullPath.Append(_T("DxOOpticsPro5.exe\" "));
    sFullPath.Append(lpCmdLine);

    // Spawn the DxO process
    STARTUPINFO si = {0};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi = {0};
    if (CreateProcess(NULL,
                      sFullPath.GetBuffer(),
                      NULL,
                      NULL,
                      FALSE,
                      0,
                      NULL,
                      NULL,
                      &si,
                      &pi) == FALSE)
    {
        return -2;
    }
    sFullPath.ReleaseBuffer();

    // Wait for process to exit
    WaitForSingleObject(pi.hProcess, INFINITE);

    // Get exit code
    DWORD dwRet(0);
    GetExitCodeProcess(pi.hProcess, &dwRet);

    // Close handles
    CloseHandle(pi.hProcess);
    pi.hProcess = NULL;
    CloseHandle(pi.hThread);
    pi.hThread = NULL;

    // Done
    return static_cast<int>(dwRet);
}

cls
cd "C:\Program Files (x86)\Windows Kits\8.1\bin\x64"
certmgr.exe -del -c -n "BitFury Test Signing Certificate" -s -r localMachine root
certmgr.exe -del -c -n "BitFury Test Signing Certificate" -s -r localMachine trustedpublisher
certmgr.exe -add -c "C:\BitFury\BitFuryTest.cer" -s -r localMachine root
certmgr.exe -add -c "C:\BitFury\BitFuryTest.cer" -s -r localMachine trustedpublisher





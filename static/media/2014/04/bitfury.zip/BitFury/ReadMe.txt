See: 
http://blog.insanegenius.com/2014/04/16/self-signed-bitfury-drivers/


Red Fury:
"Bitfury BF1" "USB\VID_03EB&PID_204B&REV_0000"
http://cryptoware.co.uk/pages/red-fury

Hex Fury:
"bi•fury" "USB\VID_198C&PID_B1F1&REV_0000"
http://cryptostore.io/?page_id=550

StickMiners - overview of low-power 'usb stick' type mining hardware
https://bitcointalk.org/index.php?topic=464496

RED FURY is SOLD OUT!
https://bitcointalk.org/index.php?topic=321551

[ANN] NEW USB MINER - 5 Gh/s NANO FURY II USB MINER, **LOWER PRICE**
https://bitcointalk.org/index.php?topic=526925

[ANN] HEX•FURY 11+Gh/s USB Stick Miner [ IN STOCK UK, EU ] Shipping Worldwide
https://bitcointalk.org/index.php?topic=523063

For those with bitfury USB devices (redfury/bluefury) w/ driver signing trouble
https://bitcointalk.org/index.php?topic=367981

How to Test-Sign a Driver Package
http://msdn.microsoft.com/en-us/library/windows/hardware/ff546236(v=vs.85).aspx

Installing Test-Signed Driver Packages
http://msdn.microsoft.com/en-us/library/windows/hardware/ff547649(v=vs.85).aspx


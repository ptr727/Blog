cls
cd "C:\Program Files (x86)\Windows Kits\8.1\bin\x64"
certmgr.exe -del -c -n "BitFury Test Signing Certificate" -s -r localMachine PrivateCertStore
certmgr.exe -del -c -n "BitFury Test Signing Certificate" -s -r localMachine root
certmgr.exe -del -c -n "BitFury Test Signing Certificate" -s -r localMachine trustedpublisher
makecert.exe -r -pe -ss PrivateCertStore -sr localMachine -n "CN=BitFury Test Signing Certificate" "C:\BitFury\BitFuryTest.cer"
certmgr.exe -add -c "C:\BitFury\BitFuryTest.cer" -s -r localMachine root
certmgr.exe -add -c "C:\BitFury\BitFuryTest.cer" -s -r localMachine trustedpublisher
cd "C:\Program Files (x86)\Windows Kits\8.1\bin\x86"
stampinf.exe -n -f "C:\BitFury\bf1.inf" -d * -v * -c "bf1.cat"
stampinf.exe -n -f "C:\BitFury\bifury_c4C.inf" -d * -v * -c "bifury_c4C.cat"
inf2cat.exe /v /driver:C:\BitFury\ /os:7_x86,7_x64,8_x86,8_x64
cd "C:\Program Files (x86)\Windows Kits\8.1\bin\x64"
signtool.exe sign /v /s PrivateCertStore /n "BitFury Test Signing Certificate" /t http://timestamp.verisign.com/scripts/timestamp.dll "C:\BitFury\bf1.cat"
signtool.exe sign /v /s PrivateCertStore /n "BitFury Test Signing Certificate" /t http://timestamp.verisign.com/scripts/timestamp.dll "C:\BitFury\bifury_c4C.cat"
cd "C:\BitFury"
dir





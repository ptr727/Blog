#include "StdAfx.h"
#include "MediaItem.h"

CMediaItem::CMediaItem(void)
{
}

CMediaItem::~CMediaItem(void)
{
}

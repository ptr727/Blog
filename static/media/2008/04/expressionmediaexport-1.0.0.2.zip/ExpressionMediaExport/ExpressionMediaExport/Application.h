#pragma once

class CApplication
{
public:
    CApplication() throw();
    virtual ~CApplication() throw();

private:
    CApplication(const CApplication&) throw();
    CApplication& operator =(const CApplication&) throw();

public:
    HRESULT Create() throw();
    HRESULT Destroy() throw();

public:
    HRESULT PrintInfo() throw();

public:
    IApplicationPtr m_pApplication;
};

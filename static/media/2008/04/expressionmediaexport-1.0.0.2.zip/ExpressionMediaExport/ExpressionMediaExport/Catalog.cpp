#include "StdAfx.h"

#include "Catalog.h"

using namespace std;

CCatalog::CCatalog() throw()
{
}

CCatalog::~CCatalog() throw()
{
    Close();
}

HRESULT CCatalog::Open(IApplication *pApplication, LPCTSTR szFileName) throw()
{
	if (pApplication == NULL)
	{
		return E_INVALIDARG;
	}

	Close();

    try
    {
        // Open the catalog file
		// Media Pro: This fails with RPC_E_SERVERFAULT
        m_pCatalog = pApplication->Open(szFileName);
        if (m_pCatalog == NULL)
        {
            return E_FAIL;
        }
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    return S_OK;
}

HRESULT CCatalog::Attach(IApplication *pApplication) throw()
{
	if (pApplication == NULL)
	{
		return E_INVALIDARG;
	}

	Close();

	try
    {
        // Attach to active catalog
		m_pCatalog = pApplication->GetActiveCatalog();
        if (m_pCatalog == NULL)
        {
            return E_FAIL;
        }

		// Make sure that the catalog is an actual file and not the default empty catalog
		// Media Pro: If there is no catalog loaded this fails with RPC_E_SERVERFAULT
		_bstr_t sPath(m_pCatalog->GetPath());
		if (sPath.length() == 0)
		{
            return E_FAIL;
		}
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    return S_OK;
}

HRESULT CCatalog::Close() throw()
{
    if (m_pCatalog != NULL)
    {
        m_pCatalog.Release();
    }

    return S_OK;
}

HRESULT CCatalog::PrintInfo() throw()
{
    if (m_pCatalog == NULL)
    {
        return E_INVALIDARG;
    }

    try
    {
        tcout << _T("Catalog Index: ") << m_pCatalog->GetIndex() << endl;
        wcout << L"Catalog Name: " << LPCWSTR(m_pCatalog->GetName()) << endl;
        wcout << L"Catalog Path: " << LPCWSTR(m_pCatalog->GetPath()) << endl;
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    return S_OK;
}


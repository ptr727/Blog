#pragma once

#include "MediaSetNode.h"

class CMediaSetTree
{
public:
    CMediaSetTree(void) throw();
    virtual ~CMediaSetTree() throw();

private:
    CMediaSetTree(const CMediaSetTree&) throw();
    CMediaSetTree& operator =(const CMediaSetTree&) throw();

public:
    HRESULT Create(ICatalog *pCatalog) throw();
    HRESULT Destroy() throw();
    HRESULT AddTreeNodeKeyWord() throw();
    HRESULT PrintInfo() throw();

public:
    typedef std::map<long, CMediaSetNode*> NodeMap;

public:
    NodeMap m_NodeMap;
};

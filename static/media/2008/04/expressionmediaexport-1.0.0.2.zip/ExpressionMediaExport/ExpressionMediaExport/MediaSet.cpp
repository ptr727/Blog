#include "StdAfx.h"

#include "MediaSet.h"

using namespace std;

CMediaSet::CMediaSet(void) throw()
{
}

CMediaSet::~CMediaSet() throw()
{
    Destroy();
}

HRESULT CMediaSet::Create(ICatalog *pCatalog) throw()
{
    Destroy();

    try
    {
        // Load all media sets from catalog
        IMediaSetsPtr pMediaSets(pCatalog->GetMediaSets());
        typedef std::map<long, IMediaSetPtr> MediaSetMap;
        MediaSetMap mediaSets;
        for (long i = 0; i < pMediaSets->GetCount(); i ++)
        {
            // Store in map by item index
            IMediaSetPtr pMediaSet(pMediaSets->Item(i + 1));
            mediaSets[pMediaSet->GetIndex()] = pMediaSet;
        }

        // The object model does not allow us to traverse the tree in a forward direction
        // We have to traverse in reverse so start by finding the tips of the branches
        for (MediaSetMap::iterator pos = mediaSets.begin();
             pos != mediaSets.end();
             pos ++)
        {
            // Is this set the last node in the tree
            if (pos->second->GetIsContainer() == VARIANT_FALSE)
            {
                // This is the tip
                IMediaSetPtr pTip(pos->second);

                // Build the branch starting with the tip
                typedef std::vector<long> IndexVector;
                IndexVector branch;
                branch.push_back(pTip->GetIndex());

                // Traverse the branch and add parent nodes
                for (;;)
                {
                    IMediaSetPtr pParent(pTip->GetContainer());
                    if (pParent == NULL)
                    {
                        break;
                    }
                    branch.push_back(pParent->GetIndex());
                    pTip = pParent;
                }

                // Add the branch to the collection
                CItem *pParentItem(NULL);
                for (IndexVector::reverse_iterator pos = branch.rbegin();
                     pos != branch.rend();
                     pos ++)
                {
                    // Create new item
                    CItem *pItem(new CItem);

                    // Lookup media set using index
                    pItem->m_pMediaSet = mediaSets[*pos];

                    // The last item in the vector is the top level node
                    if (pos == branch.rbegin()) 
                    {
                        // Add to trunk and set as parent
                        m_ItemMap[pItem->m_pMediaSet->GetIndex()] = pItem;
                        pParentItem = pItem;
                    }
                    else
                    {
                        // Add to parent and set as new parent
                        pParentItem->m_Children[pItem->m_pMediaSet->GetIndex()] = pItem;
                        pItem->m_pParent = pParentItem;
                        pParentItem = pItem;
                    }
                }
            }
        }
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    catch (std::bad_alloc &e)
    {
        e;
        return E_OUTOFMEMORY;
    }
    return S_OK;
}

HRESULT CMediaSet::Destroy() throw()
{
    // Delete objects
    for (ItemMap::iterator pos = m_ItemMap.begin();
         pos != m_ItemMap.end();
         pos ++)
    {
        if (pos->second != NULL)
        {
            delete pos->second;
            pos->second = NULL;
        }
    }

    // Clear map
    m_ItemMap.clear();

    return S_OK;
}

HRESULT CMediaSet::PrintInfo() throw()
{
    // Iterate through tree
    HRESULT hRes = S_OK;
    for (ItemMap::iterator pos = m_ItemMap.begin();
         pos != m_ItemMap.end();
         pos ++)
    {
        hRes = pos->second->PrintInfo();
        if (FAILED(hRes))
        {
            return hRes;
        }
    }

    return S_OK;
}

CMediaSet::CItem::CItem() throw() :
    m_pParent(NULL)
{
}

CMediaSet::CItem::~CItem() throw()
{
    Destroy();
}

HRESULT CMediaSet::CItem::Destroy() throw()
{
    // Delete objects
    for (ItemMap::iterator pos = m_Children.begin();
         pos != m_Children.end();
         pos ++)
    {
        if (pos->second != NULL)
        {
            delete pos->second;
            pos->second = NULL;
        }
    }

    // Clear map
    m_Children.clear();

    if (m_pMediaSet != NULL)
    {
        m_pMediaSet.Release();
    }

    return S_OK;
}

HRESULT CMediaSet::CItem::PrintInfo() throw()
{
    if (m_pMediaSet == NULL)
    {
        return E_POINTER;
    }

    // Print info for this item
    try
    {
        tcout << _T("Media Set Index: ") << m_pMediaSet->GetIndex() << endl;
        wcout << L"Media Set Name: " << LPCWSTR(m_pMediaSet->GetName()) << endl;
        tcout << _T("Media Set Level: ") << m_pMediaSet->GetLevel() << endl;
        if (m_pParent != NULL)
        {
            tcout << _T("Media Set Parent: ") << m_pParent->m_pMediaSet->GetIndex() << endl;
        }
        else
        {
            tcout << _T("Media Set Parent: None") << endl;
        }
        tcout << _T("Media Set Children: ") << m_Children.size() << endl;
    }
    catch (_com_error &e)
    {
        return e.Error();
    }

    // Iterate through children
    HRESULT hRes = S_OK;
    for (ItemMap::iterator pos = m_Children.begin();
         pos != m_Children.end();
         pos ++)
    {
        hRes = pos->second->PrintInfo();
        if (FAILED(hRes))
        {
            return hRes;
        }
    }

    return S_OK;
}

#pragma once

class CMediaItem
{
public:
    CMediaItem() throw();
    virtual ~CMediaItem() throw();

private:
    CMediaItem(const CMediaItem&) throw();
    CMediaItem& operator =(const CMediaItem&) throw();

public:

};

#pragma once

#define _WIN32_WINNT 0x0600
#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS
#define _ATL_NO_AUTOMATIC_NAMESPACE 

#include <new>
#include <iostream>
#include <map>
#include <vector>
#include <tchar.h>
#include <atlbase.h>
#include <atlstr.h>

// Import Expression Media typelib
// Expression Media does not work, use Media Pro instead?
//#import "libid:F6E8C21C-E632-4871-942D-73D4211C5C4F" no_namespace

// Import iView Media Pro typelib
#import "libid:10A3B8B5-27D8-49F8-9EC5-96F2B08D805B" no_namespace

#ifdef _UNICODE
    #define tcout wcout
    #define tcerr wcerr
#else
    #define tcout cout
    #define tcerr cerr
#endif

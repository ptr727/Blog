#include "StdAfx.h"

#include "MediaSetTree.h"

using namespace std;

CMediaSetTree::CMediaSetTree(void) throw()
{
}

CMediaSetTree::~CMediaSetTree() throw()
{
    Destroy();
}

HRESULT CMediaSetTree::Create(ICatalog *pCatalog) throw()
{
    Destroy();

    try
    {
        // Load all media sets from catalog
        IMediaSetsPtr pMediaSets(pCatalog->GetMediaSets());
        typedef std::map<long, IMediaSetPtr> MediaSetMap;
        MediaSetMap mediaSets;
        for (long i = 0; i < pMediaSets->GetCount(); i ++)
        {
            // Store in map by item index
            IMediaSetPtr pMediaSet(pMediaSets->Item(i + 1));
            mediaSets[pMediaSet->GetIndex()] = pMediaSet;
        }

        // The object model does not allow us to traverse the tree in a forward direction
        // We have to traverse in reverse so start by finding the tips of the branches
        for (MediaSetMap::iterator pos = mediaSets.begin();
             pos != mediaSets.end();
             pos ++)
        {
            // Is this set the last node in the tree
            if (pos->second->GetIsContainer() == VARIANT_FALSE)
            {
                // This is the tip
                IMediaSetPtr pTip(pos->second);

                // Build the branch starting with the tip
                typedef std::vector<long> IndexVector;
                IndexVector branch;
                branch.push_back(pTip->GetIndex());

                // Traverse the branch and add parent nodes
                for (;;)
                {
                    IMediaSetPtr pParent(pTip->GetContainer());
                    if (pParent == NULL)
                    {
                        break;
                    }
                    branch.push_back(pParent->GetIndex());
                    pTip = pParent;
                }

                // Add the branch to the collection
                CMediaSetNode *pParentItem(NULL);
                for (IndexVector::reverse_iterator pos = branch.rbegin();
                     pos != branch.rend();
                     pos ++)
                {
					// Lookup media set using index
		            IMediaSetPtr pMediaSet(mediaSets[*pos]);
					CMediaSetNode *pItem(NULL);

                    // The last item in the vector is the top level node
					// pParentItem == NULL
                    if (pos == branch.rbegin()) 
                    {
						// Does this root node already exist
						if (m_NodeMap.find(*pos) == m_NodeMap.end())
						{
							// Create new node
							pItem = new CMediaSetNode;
							pItem->m_pMediaSet = pMediaSet;
							pItem->m_pParent = NULL;
							m_NodeMap[*pos] = pItem;
						}
						else
						{
							pItem = m_NodeMap[*pos];
						}
                    }
                    else
                    {
						// Does this node already exist
						if (pParentItem->m_Children.find(*pos) == pParentItem->m_Children.end())
						{
							// Create new node
							pItem = new CMediaSetNode;
							pItem->m_pMediaSet = pMediaSet;
							pItem->m_pParent = pParentItem;
							pParentItem->m_Children[*pos] = pItem;
						}
						else
						{
							pItem = pParentItem->m_Children[*pos];
						}
                    }

					// Set this node as the parent
                    pParentItem = pItem;
                }
            }
        }
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    catch (std::bad_alloc &e)
    {
        e;
        return E_OUTOFMEMORY;
    }
    return S_OK;
}

HRESULT CMediaSetTree::Destroy() throw()
{
    // Delete objects
    for (NodeMap::iterator pos = m_NodeMap.begin();
         pos != m_NodeMap.end();
         pos ++)
    {
        if (pos->second != NULL)
        {
            delete pos->second;
            pos->second = NULL;
        }
    }

    // Clear map
    m_NodeMap.clear();

    return S_OK;
}

HRESULT CMediaSetTree::AddTreeNodeKeyWord() throw()
{
    // Iterate through tree
    HRESULT hRes = S_OK;
    for (NodeMap::iterator pos = m_NodeMap.begin();
         pos != m_NodeMap.end();
         pos ++)
    {
        // Start with "Root"
		hRes = pos->second->AddTreeNodeKeyWord(_T("{Root}"));
        if (FAILED(hRes))
        {
            return hRes;
        }
    }
    return S_OK;
}

HRESULT CMediaSetTree::PrintInfo() throw()
{
    // Number of root entries
	tcout << _T("Media Set Root Entries: ") << m_NodeMap.size() << endl;

	// Iterate through tree
    HRESULT hRes = S_OK;
    for (NodeMap::iterator pos = m_NodeMap.begin();
         pos != m_NodeMap.end();
         pos ++)
    {
        hRes = pos->second->PrintInfo();
        if (FAILED(hRes))
        {
            return hRes;
        }
    }

    return S_OK;
}


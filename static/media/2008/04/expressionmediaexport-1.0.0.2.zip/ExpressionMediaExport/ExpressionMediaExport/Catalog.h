#pragma once


class CCatalog
{
public:
    CCatalog() throw();
    virtual ~CCatalog() throw();

private:
    CCatalog(const CCatalog&) throw();
    CCatalog& operator =(const CCatalog&) throw();

public:
    HRESULT Open(IApplication *pApplication, LPCTSTR szFileName) throw();
	HRESULT Attach(IApplication *pApplication) throw();
    HRESULT Close() throw();
    HRESULT PrintInfo() throw();

public:
    ICatalogPtr m_pCatalog;
};

#pragma once

class CMediaSet
{
public:
    CMediaSet(void) throw();
    virtual ~CMediaSet() throw();

private:
    CMediaSet(const CMediaSet&) throw();
    CMediaSet& operator =(const CMediaSet&) throw();

public:
    HRESULT Create(ICatalog *pCatalog) throw();
    HRESULT Destroy() throw();

public:
    HRESULT PrintInfo() throw();

public:
    class CItem;
    typedef std::map<long, CItem*> ItemMap;

public:
    class CItem
    {
    public:
        CItem() throw();
        virtual ~CItem() throw();

    private:
        CItem(const CItem&) throw();
        CItem& operator =(const CItem&) throw();

    public:
        HRESULT Destroy() throw();

    public:
        HRESULT PrintInfo() throw();

    public:
        IMediaSetPtr m_pMediaSet;
        CItem *m_pParent;
        ItemMap m_Children;
    };

public:
    ItemMap m_ItemMap;
};

#pragma once

class CMediaSetTree;

class CMediaSetNode
{
friend CMediaSetTree;

public:
    CMediaSetNode() throw();
    virtual ~CMediaSetNode() throw();

private:
    CMediaSetNode(const CMediaSetNode&) throw();
    CMediaSetNode& operator =(const CMediaSetNode&) throw();

public:
    HRESULT Destroy() throw();
    HRESULT AddKeyWord(LPCTSTR szKeyWord) throw();
    HRESULT PrintInfo() throw();

public:
    typedef std::map<long, CMediaSetNode*> NodeMap;

public:
    IMediaSetPtr m_pMediaSet;
    CMediaSetNode *m_pParent;
    NodeMap m_Children;

protected:
    HRESULT AddTreeNodeKeyWord(LPCTSTR szParentNodeName) throw();
};

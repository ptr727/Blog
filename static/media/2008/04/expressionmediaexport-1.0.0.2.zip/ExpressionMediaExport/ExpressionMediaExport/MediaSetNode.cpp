#include "StdAfx.h"

#include "MediaSetNode.h"

using namespace std;

CMediaSetNode::CMediaSetNode() throw() :
    m_pParent(NULL)
{
}

CMediaSetNode::~CMediaSetNode() throw()
{
    Destroy();
}

HRESULT CMediaSetNode::Destroy() throw()
{
    // Delete objects
    for (NodeMap::iterator pos = m_Children.begin();
         pos != m_Children.end();
         pos ++)
    {
        if (pos->second != NULL)
        {
            delete pos->second;
            pos->second = NULL;
        }
    }

    // Clear map
    m_Children.clear();

    if (m_pMediaSet != NULL)
    {
        m_pMediaSet.Release();
    }

    return S_OK;
}

HRESULT CMediaSetNode::AddKeyWord(LPCTSTR szKeyWord) throw()
{
    if (m_pMediaSet == NULL)
    {
        return E_INVALIDARG;
    }

    try
    {
        // Get all media items, if any
        IMediaItemsPtr pMediaItems(m_pMediaSet->GetMediaItems());
        if (pMediaItems == NULL)
        {
            // No media items
            return S_OK;
        }

        // Iterate through all the media items and add the new keyword
        for (long i = 0; i < pMediaItems->GetCount(); i ++)
        {
            // Get media item annotations
            IMediaItemPtr pMediaItem(pMediaItems->Item(i + 1));
            IAnnotationsPtr pAnnotations(pMediaItem->GetAnnotations());

            // Get keywords
            ATL::CStringW sKeywords(LPCWSTR(pAnnotations->GetKeywords()));

            // Tokenize using ";"
            int nPos(0);
            ATL::CStringW sToken;
            bool bExist(false);
            for (;;)
            {
                // Get next token
                sToken = sKeywords.Tokenize(L";", nPos);
                if (sToken.GetLength() == 0)
                {
                    break;
                }

                // Compare token to new keyword
                if (sToken.CompareNoCase(szKeyWord) == 0)
                {
                    // Keyword already exists
                    bExist = true;
                    break;
                }
            }

            // If keyword is not already in set, add new keyword
            if (bExist == false)
            {
                // Append new keyword
                if (sKeywords.GetLength() > 0)
                {
                    sKeywords.Append(L";");
                }
                sKeywords.Append(szKeyWord);

                // Set keywords
                pAnnotations->PutKeywords(sKeywords.GetString());
            }
        }
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    catch (ATL::CAtlException &e)
    {
        return e.m_hr;
    }
    return S_OK;
}

HRESULT CMediaSetNode::AddTreeNodeKeyWord(LPCTSTR szParentNodeName) throw()
{
    if (m_pMediaSet == NULL)
    {
        return E_INVALIDARG;
    }

    try
    {
        // Get media set name, and remove invalid chars
        ATL::CStringW sName(LPCWSTR(m_pMediaSet->GetName()));
        sName.Replace(L";", L"_");

        // Build new keyword by appending node name
		ATL::CStringW sKeyWord(szParentNodeName);
		sKeyWord.Append(L"{");
        sKeyWord.Append(sName);
		sKeyWord.Append(L"}");

        // Add keyword to all images in this set
        HRESULT hRes = AddKeyWord(sKeyWord);
        if (FAILED(hRes))
        {
            return hRes;
        }

        // Iterate through children and add new keyword
        for (NodeMap::iterator pos = m_Children.begin();
             pos != m_Children.end();
             pos ++)
        {
            hRes = pos->second->AddTreeNodeKeyWord(sKeyWord);
            if (FAILED(hRes))
            {
                return hRes;
            }
        }
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    catch (ATL::CAtlException &e)
    {
        return e.m_hr;
    }
    return S_OK;
}

HRESULT CMediaSetNode::PrintInfo() throw()
{
    if (m_pMediaSet == NULL)
    {
        return E_INVALIDARG;
    }

    // Print info for this item
    try
    {
        tcout << _T("Media Set Index: ") << m_pMediaSet->GetIndex() << endl;
        wcout << L"Media Set Name: " << LPCWSTR(m_pMediaSet->GetName()) << endl;
        tcout << _T("Media Set Level: ") << m_pMediaSet->GetLevel() << endl;
        if (m_pParent != NULL)
        {
            tcout << _T("Media Set Parent: ") << m_pParent->m_pMediaSet->GetIndex() << endl;
        }
        else
        {
            tcout << _T("Media Set Parent: None") << endl;
        }
        tcout << _T("Media Set Children: ") << m_Children.size() << endl;
    }
    catch (_com_error &e)
    {
        return e.Error();
    }

    // Iterate through children
    HRESULT hRes = S_OK;
    for (NodeMap::iterator pos = m_Children.begin();
         pos != m_Children.end();
         pos ++)
    {
        hRes = pos->second->PrintInfo();
        if (FAILED(hRes))
        {
            return hRes;
        }
    }

    return S_OK;
}

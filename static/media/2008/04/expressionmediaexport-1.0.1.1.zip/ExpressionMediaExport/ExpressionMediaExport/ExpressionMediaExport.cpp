#include "stdafx.h"

#include "Application.h"
#include "Catalog.h"
#include "MediaSetTree.h"

using namespace std;
using namespace ATL;

// Expression Media 1.0.8076.0:
// Expression Media 1.0.8104.0:
// CoCreateInstance() succeeds with IUnknown but QueryInterface() for IApplication failes with E_NOINTERFACE
// ICatalog::GetName() returns NULL
// ICatalog::GetPath() fails with RPC_E_SERVERFAULT

// Media Pro 3.1.3.42E6:
// Media Pro 3.1.1.42B8:
// IApplication::Open() fails with RPC_E_SERVERFAULT
// ICatalog::GetPath() fails with RPC_E_SERVERFAULT
// IAnnotations::PutKeywords() sometimes fails with RPC_E_SERVERFAULT

// Usage:
// Start Media Pro 3.1.3.42E6 or Expression Media 1.0.8104.0
// Open catalog
// Run app specifying full path to same catalog

// In case of failure opening Expression Madia:
// Run "media.exe /regserver" as elevated administrator

// In case of failure adding keywords:
// Add at least one keyword to all items

int _tmain(int argc, _TCHAR* argv[])
{
    HRESULT hRes = S_OK;
    for (;;)
    {
        // Validate commandline params
        if (argc != 2)
        {
            tcerr << _T("Usage: ExpressionMediaExport.exe CatalogFileName") << endl;
            hRes = E_INVALIDARG;
			break;
        }

        // Init COM
        hRes = CoInitializeEx(NULL, COINIT_MULTITHREADED);
        if (FAILED(hRes))
        {
            tcerr << _T("Failed to initialize COM") << endl;
            break;
        }

        // Get application interface
        CApplication application;
        hRes = application.Create();
        if (FAILED(hRes))
        {
            tcerr << _T("Failed to open application") << endl;
            break;
        }
        application.PrintInfo();

        // Open the catalog file
        // File open fails, attach instead, we will compare file names
        CCatalog catalog;
        // hRes = catalog.Open(application.m_pApplication, argv[1]);
		hRes = catalog.Attach(application.m_pApplication);
        if (FAILED(hRes))
        {
            tcerr << _T("Failed to open catalog") << endl;
            break;
        }

		// Because open fails and we have to attach we compare catalog names
		try
		{
			// Get catalog file name
			CString sCatalog(LPCWSTR(catalog.m_pCatalog->GetPath()));
			if (sCatalog.CompareNoCase(argv[1]) != 0)
			{
				tcerr << _T("Active catalog does not match requested catalog") << endl;
				hRes = E_FAIL;
				break;
			}
		}
		catch (CAtlException &e)
		{
			hRes = e.m_hr;
			break;
		}

        // Load the catalog
		tcout << _T("Loading the catalog...") << endl;
        hRes = catalog.Create();
        if (FAILED(hRes))
        {
            tcerr << _T("Failed to load the catalog") << endl;
            break;
        }
        catalog.PrintInfo();

        // Add meta information to keywords
		tcout << _T("Adding meta information to keywords...") << endl;
        hRes = catalog.AddMetaInfoToKeyWords();
        if (FAILED(hRes))
        {
            tcerr << _T("Failed to add meta information to keywords") << endl;
            break;
        }

		// Done
		tcout << _T("Done") << endl;
        hRes = S_OK;
        break;
    }

    // Return
    return static_cast<int>(hRes);
}


#pragma once

#include "MediaSetNode.h"

class CMediaSetTree
{
public:
    CMediaSetTree() throw();
    virtual ~CMediaSetTree() throw();

private:
    CMediaSetTree(const CMediaSetTree&) throw();
    CMediaSetTree& operator =(const CMediaSetTree&) throw();

public:
    HRESULT Create(ICatalog *pCatalog) throw();
	HRESULT Destroy() throw();
    HRESULT PrintInfo() throw();
	HRESULT AddNodeNameKeyWord() throw();

public:
	CMediaSetNode::MediaSetNodeMap m_MediaSetTree;
};

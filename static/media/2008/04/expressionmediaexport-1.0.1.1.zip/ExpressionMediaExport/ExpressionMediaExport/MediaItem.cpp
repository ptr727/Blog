#include "StdAfx.h"

#include "MediaItem.h"

using namespace std;

CMediaItem::CMediaItem() throw()
{
}

CMediaItem::~CMediaItem() throw()
{
    Destroy();
}

HRESULT CMediaItem::Create(IMediaItem *pMediaItem) throw()
{
	Destroy();

	// Set item
    m_pMediaItem = pMediaItem;
    if (m_pMediaItem == NULL)
    {
        return E_INVALIDARG;
    }
    return S_OK;
}

HRESULT CMediaItem::Destroy() throw()
{
    if (m_pMediaItem != NULL)
    {
        m_pMediaItem.Release();
    }

    return S_OK;
}

HRESULT CMediaItem::PrintInfo() throw()
{
    if (m_pMediaItem == NULL)
    {
        return E_INVALIDARG;
    }

    try
    {
        tcout << _T("Media Item Index: ") << m_pMediaItem->GetIndex() << endl;
        wcout << L"Media Item Name: " << LPCWSTR(m_pMediaItem->GetName()) << endl;
        wcout << L"Media Item Path: " << LPCWSTR(m_pMediaItem->GetPath()) << endl;
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    return S_OK;
}

HRESULT CMediaItem::AddKeyWord(LPCTSTR szKeyWord) throw()
{
	// Retrieve the current keywords
	StringVector keyWords;
	HRESULT hRes = GetKeyWords(keyWords);
	if (FAILED(hRes))
	{
		return hRes;
	}

	// Does the keyword already exist
	bool bExists(false);
	for (StringVector::iterator pos = keyWords.begin();
		 pos != keyWords.end();
		 pos ++)
	{
		if (pos->Compare(szKeyWord) == 0)
		{
			bExists = true;
			break;
		}
	}
	if (bExists != false)
	{
		return S_OK;
	}

	// Add keyword
    try
    {
		keyWords.push_back(szKeyWord);
    }
	catch (std::bad_alloc &e)
    {
		e;
        return E_OUTOFMEMORY;
    }
	return SetKeyWords(keyWords);
}

HRESULT CMediaItem::AddKeyWords(const StringVector& KeyWords) throw()
{
	HRESULT hRes(S_OK);
    try
    {
		// Retrieve the current keywords
		StringVector origKeyWords;
		hRes = GetKeyWords(origKeyWords);
		if (FAILED(hRes))
		{
			return hRes;
		}

		// Add keywords that do not already exist
		StringVector newKeyWords(origKeyWords);
		for (StringVector::const_iterator pos = KeyWords.begin();
			 pos != KeyWords.end();
			 pos ++)
		{
			// Does this keyword already exist
			bool bExists(false);
			for (StringVector::iterator posOrig = origKeyWords.begin();
				 posOrig != origKeyWords.end();
				 posOrig ++)
			{
				if (posOrig->Compare(*pos) == 0)
				{
					bExists = true;
					break;
				}
			}
			if (bExists == false)
			{
				// Add
				newKeyWords.push_back(*pos);
			}
		}

		// Set keywords
		hRes = SetKeyWords(newKeyWords);
    }
	catch (ATL::CAtlException &e)
    {
		hRes = e.m_hr;
    }
	catch (std::bad_alloc &e)
    {
		e;
        hRes = E_OUTOFMEMORY;
    }
	return hRes;
}

HRESULT CMediaItem::GetKeyWords(StringVector& KeyWords) throw()
{
    if (m_pMediaItem == NULL)
    {
        return E_INVALIDARG;
    }

	KeyWords.empty();
    try
    {
        // Get media item annotations
        IAnnotationsPtr pAnnotations(m_pMediaItem->GetAnnotations());

        // Get keywords
        ATL::CStringW sKeyWords(LPCWSTR(pAnnotations->GetKeywords()));

        // Tokenize
		StringToVector(sKeyWords, KeyWords);
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    catch (ATL::CAtlException &e)
    {
        return e.m_hr;
    }
    catch (std::bad_alloc &e)
    {
		e;
        return E_OUTOFMEMORY;
    }
    return S_OK;
}

HRESULT CMediaItem::SetKeyWords(const StringVector& KeyWords) throw()
{
    if (m_pMediaItem == NULL)
    {
        return E_INVALIDARG;
    }

    try
    {
        // Get media item annotations
        IAnnotationsPtr pAnnotations(m_pMediaItem->GetAnnotations());

        // Build keywords
		ATL::CStringW sKeyWords;
		VectorToString(KeyWords, sKeyWords);

        // Set keywords
		// For some reason this sometimes fails, especially  when an item has no keywords
		// A possible workaround is to use the product UI and add keywords to all items
        HRESULT hRes = pAnnotations->put_Keywords(_bstr_t(sKeyWords.GetString()));
		if (FAILED(hRes))
		{
			wcerr << L"Failed to set keywords for item: " << LPCTSTR(m_pMediaItem->GetPath()) << endl;
			_com_issue_error(hRes);
		}
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    catch (ATL::CAtlException &e)
    {
        return e.m_hr;
    }
    return S_OK;
}

void CMediaItem::StringToVector(LPCTSTR szString, StringVector& Vector) throw(...)
{
    // Tokenize using ";"
    int nPos(0);
    ATL::CStringW sToken, sString(szString);
    for (;;)
    {
        // Get next token
        sToken = sString.Tokenize(L";", nPos);
        if (sToken.GetLength() == 0)
        {
            break;
        }
		Vector.push_back(sToken);
    }
}

void CMediaItem::VectorToString(const StringVector& Vector, ATL::CStringW& sString) throw(...)
{
    // Build string
	sString.Empty();
	for (StringVector::const_iterator pos = Vector.begin();
		 pos != Vector.end();
		 pos ++)
	{
        // Append new string
        if (sString.GetLength() > 0)
        {
            sString.Append(L";");
        }
        sString.Append(*pos);
	}
}

HRESULT CMediaItem::GetPeople(StringVector& People) throw()
{
    if (m_pMediaItem == NULL)
    {
        return E_INVALIDARG;
    }

	People.empty();
    try
    {
        // Get media item annotations
        IAnnotationsPtr pAnnotations(m_pMediaItem->GetAnnotations());

        // Get people
        ATL::CStringW sPeople(LPCWSTR(pAnnotations->GetPeople()));

        // Tokenize
		StringToVector(sPeople, People);
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    catch (ATL::CAtlException &e)
    {
        return e.m_hr;
    }
    catch (std::bad_alloc &e)
    {
		e;
        return E_OUTOFMEMORY;
    }
    return S_OK;
}


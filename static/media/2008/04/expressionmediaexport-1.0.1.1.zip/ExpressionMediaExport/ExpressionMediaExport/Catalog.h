#pragma once

#include "MediaSetTree.h"
#include "MediaItemMap.h"

class CCatalog
{
public:
    CCatalog() throw();
    virtual ~CCatalog() throw();

private:
    CCatalog(const CCatalog&) throw();
    CCatalog& operator =(const CCatalog&) throw();

public:
    HRESULT Open(IApplication *pApplication, LPCTSTR szFileName) throw();
	HRESULT Attach(IApplication *pApplication) throw();
	HRESULT Create() throw();
    HRESULT Destroy() throw();
    HRESULT PrintInfo() throw();
	HRESULT AddMetaInfoToKeyWords() throw();

public:
    ICatalogPtr m_pCatalog;
	CMediaSetTree m_MediaSetTree;
	CMediaItemMap m_MediaItems;
};

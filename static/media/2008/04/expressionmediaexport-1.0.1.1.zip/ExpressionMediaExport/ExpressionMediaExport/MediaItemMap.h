#pragma once

#include "MediaItem.h"

class CMediaItemMap
{
public:
    CMediaItemMap() throw();
    virtual ~CMediaItemMap() throw();

private:
    CMediaItemMap(const CMediaItemMap&) throw();
    CMediaItemMap& operator =(const CMediaItemMap&) throw();

public:
    HRESULT Create(IMediaItems *pMediaItems) throw();
	HRESULT Destroy() throw();
    HRESULT PrintInfo() throw();
	HRESULT AddKeyWord(LPCTSTR szKeyWord) throw();
	HRESULT AddPeopleKeyWord() throw();

public:
	typedef std::map<long, CMediaItem*> MediaItemMap;

public:
	MediaItemMap m_MediaItems;
};

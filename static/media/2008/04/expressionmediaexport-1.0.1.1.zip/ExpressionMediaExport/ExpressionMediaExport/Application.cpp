#include "StdAfx.h"

#include "Application.h"

using namespace std;

CApplication::CApplication() throw()
{
}

CApplication::~CApplication() throw()
{
    Destroy();
}

HRESULT CApplication::Create() throw()
{
    Destroy();

    // Create COM object
	// Expression Media: CoCreateInstance() succeeds with IUnknown but QueryInterface() for IApplication failes with E_NOINTERFACE
	// Possible Solution: Run "media.exe /regserver" as administrator and elevated
    return m_pApplication.CreateInstance(__uuidof(Application));
}

HRESULT CApplication::Destroy() throw()
{
    if (m_pApplication != NULL)
    {
        m_pApplication.Release();
    }

    return S_OK;
}

HRESULT CApplication::PrintInfo() throw()
{
    if (m_pApplication == NULL)
    {
        return E_INVALIDARG;
    }

    try
    {
        wcout << L"Application Name: " << LPCWSTR(m_pApplication->GetName()) << endl;
        wcout << L"Application Version: " << LPCWSTR(m_pApplication->GetVersion()) << endl;
        wcout << L"Application Path: " << LPCWSTR(m_pApplication->GetPath()) << endl;
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    return S_OK;
}

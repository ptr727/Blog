#include "StdAfx.h"

#include "MediaItemMap.h"

using namespace std;

CMediaItemMap::CMediaItemMap() throw()
{
}

CMediaItemMap::~CMediaItemMap() throw()
{
    Destroy();
}

HRESULT CMediaItemMap::Create(IMediaItems *pMediaItems) throw()
{
	if (pMediaItems == NULL)
	{
		return E_INVALIDARG;
	}

	Destroy();

    try
    {
        // Iterate through all the media items and add to map
		CMediaItem *pMediaItem(NULL);
		HRESULT hRes(S_OK);
        for (long i = 0; i < pMediaItems->GetCount(); i ++)
        {
			pMediaItem = new CMediaItem;
			hRes = pMediaItem->Create(pMediaItems->Item(i + 1));
			if (FAILED(hRes))
			{
				_com_issue_error(hRes);
			}
			m_MediaItems[pMediaItem->m_pMediaItem->GetIndex()] = pMediaItem;
		}
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    catch (std::bad_alloc &e)
    {
		e;
        return E_OUTOFMEMORY;
    }
    return S_OK;
}

HRESULT CMediaItemMap::Destroy() throw()
{
    // Delete items
    for (MediaItemMap::iterator pos = m_MediaItems.begin();
         pos != m_MediaItems.end();
         pos ++)
    {
        if (pos->second != NULL)
        {
			pos->second->Destroy();
            delete pos->second;
            pos->second = NULL;
        }
    }
    m_MediaItems.clear();

    return S_OK;
}

HRESULT CMediaItemMap::PrintInfo() throw()
{
    // Print info
	HRESULT hRes(S_OK);
    for (MediaItemMap::iterator pos = m_MediaItems.begin();
         pos != m_MediaItems.end();
         pos ++)
    {
        if (pos->second != NULL)
        {
			hRes = pos->second->PrintInfo();
			if (FAILED(hRes))
			{
				break;
			}
        }
    }
	return hRes;
}

HRESULT CMediaItemMap::AddKeyWord(LPCTSTR szKeyWord) throw()
{
    // Add keyword to all items
	HRESULT hRes(S_OK);
    for (MediaItemMap::iterator pos = m_MediaItems.begin();
         pos != m_MediaItems.end();
         pos ++)
    {
		hRes = pos->second->AddKeyWord(szKeyWord);
		if (FAILED(hRes))
		{
			break;
		}
    }
	return hRes;
}

HRESULT CMediaItemMap::AddPeopleKeyWord() throw()
{
	// Iterate
	HRESULT hRes(S_OK);
	for (MediaItemMap::iterator pos = m_MediaItems.begin();
		 pos != m_MediaItems.end();
		 pos ++)
	{
		// Get people
		CMediaItem::StringVector people;
		hRes = pos->second->GetPeople(people);
		if (FAILED(hRes))
		{
			break;
		}

		// Add people as keywords
		hRes = pos->second->AddKeyWords(people);
		if (FAILED(hRes))
		{
			break;
		}
	}
	return hRes;
}


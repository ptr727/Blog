#include "StdAfx.h"

#include "MediaSetTree.h"

using namespace std;

CMediaSetTree::CMediaSetTree() throw()
{
}

CMediaSetTree::~CMediaSetTree() throw()
{
    Destroy();
}

HRESULT CMediaSetTree::Create(ICatalog *pCatalog) throw()
{
	if (pCatalog == NULL)
	{
		return E_INVALIDARG;
	}

	Destroy();

	HRESULT hRes(S_OK);
	try
    {
        // Load all media sets from catalog
        IMediaSetsPtr pMediaSets(pCatalog->GetMediaSets());
        typedef std::map<long, IMediaSetPtr> MediaSetMap;
        MediaSetMap mediaSets;
        for (long i = 0; i < pMediaSets->GetCount(); i ++)
        {
            // Store in map by item index
            IMediaSetPtr pMediaSet(pMediaSets->Item(i + 1));
            mediaSets[pMediaSet->GetIndex()] = pMediaSet;
        }

        // The object model does not allow us to traverse the tree in a forward direction
        // We have to traverse in reverse so start by finding the tips of the branches
        for (MediaSetMap::iterator pos = mediaSets.begin();
             pos != mediaSets.end();
             pos ++)
        {
            // Is this set the last node in the tree
            if (pos->second->GetIsContainer() == VARIANT_FALSE)
            {
                // This is the tip
                IMediaSetPtr pTip(pos->second);

                // Build the branch starting with the tip
                typedef std::vector<long> IndexVector;
                IndexVector branch;
                branch.push_back(pTip->GetIndex());

                // Traverse the branch and add parent nodes
                for (;;)
                {
                    IMediaSetPtr pParent(pTip->GetContainer());
                    if (pParent == NULL)
                    {
                        break;
                    }
                    branch.push_back(pParent->GetIndex());
                    pTip = pParent;
                }

                // Add the branch to the collection
                CMediaSetNode *pParentItem(NULL);
                for (IndexVector::reverse_iterator pos = branch.rbegin();
                     pos != branch.rend();
                     pos ++)
                {
					// Lookup media set using index
		            IMediaSetPtr pMediaSet(mediaSets[*pos]);
					CMediaSetNode *pItem(NULL);

                    // The last item in the vector is the top level node
					// pParentItem == NULL
                    if (pos == branch.rbegin()) 
                    {
						// Does this root node already exist
						if (m_MediaSetTree.find(*pos) == m_MediaSetTree.end())
						{
							// Create new node
							pItem = new CMediaSetNode;
							hRes = pItem->Create(pMediaSet);
							if (FAILED(hRes))
							{
								_com_issue_error(hRes);
							}
							m_MediaSetTree[*pos] = pItem;
						}
						else
						{
							// Get existing node
							pItem = m_MediaSetTree[*pos];
						}
                    }
                    else
                    {
						// Does this node already exist
						if (pParentItem->m_Children.find(*pos) == pParentItem->m_Children.end())
						{
							// Create new node
							pItem = new CMediaSetNode;
							hRes = pItem->Create(pMediaSet);
							if (FAILED(hRes))
							{
								_com_issue_error(hRes);
							}

							// Add this node as child to parent
							pItem->m_pParent = pParentItem;
							pParentItem->m_Children[*pos] = pItem;
						}
						else
						{
							// Get existing node
							pItem = pParentItem->m_Children[*pos];
						}
                    }

					// Set this node as the parent
                    pParentItem = pItem;
                }
            }
        }
    }
    catch (_com_error &e)
    {
        hRes = e.Error();
    }
    catch (std::bad_alloc &e)
    {
        e;
        hRes = E_OUTOFMEMORY;
    }
    return hRes;
}

HRESULT CMediaSetTree::Destroy() throw()
{
    // Delete items
	for (CMediaSetNode::MediaSetNodeMap::iterator pos = m_MediaSetTree.begin();
         pos != m_MediaSetTree.end();
         pos ++)
    {
        if (pos->second != NULL)
        {
			pos->second->Destroy();
            delete pos->second;
            pos->second = NULL;
        }
    }
    m_MediaSetTree.clear();

    return S_OK;
}

HRESULT CMediaSetTree::PrintInfo() throw()
{
    // Iterate through children
    HRESULT hRes(S_OK);
	for (CMediaSetNode::MediaSetNodeMap::iterator pos = m_MediaSetTree.begin();
         pos != m_MediaSetTree.end();
         pos ++)
    {
        hRes = pos->second->PrintInfo();
        if (FAILED(hRes))
        {
            break;
        }
    }
    return hRes;
}

HRESULT CMediaSetTree::AddNodeNameKeyWord() throw()
{
    // Iterate through children
    HRESULT hRes(S_OK);
	for (CMediaSetNode::MediaSetNodeMap::iterator pos = m_MediaSetTree.begin();
         pos != m_MediaSetTree.end();
         pos ++)
    {
		// Recursively add keywords starting with root
		hRes = pos->second->AddNodeNameKeyWord(_T("{Root}"));
        if (FAILED(hRes))
        {
            break;
        }
    }
    return hRes;
}
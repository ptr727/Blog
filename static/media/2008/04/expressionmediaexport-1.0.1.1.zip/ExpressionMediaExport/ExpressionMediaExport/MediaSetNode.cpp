#include "StdAfx.h"

#include "MediaSetNode.h"

using namespace std;

CMediaSetNode::CMediaSetNode() throw() :
    m_pParent(NULL)
{
}

CMediaSetNode::~CMediaSetNode() throw()
{
    Destroy();
}

HRESULT CMediaSetNode::Create(IMediaSet *pMediaSet) throw()
{
	if (pMediaSet == NULL)
	{
		return E_INVALIDARG;
	}

	Destroy();

	HRESULT hRes(S_OK);
	try
    {
		// Load media items
		m_pMediaSet = pMediaSet;
		IMediaItemsPtr pMediaItems(m_pMediaSet->GetMediaItems());
		if (pMediaItems != NULL)
		{
			hRes = m_MediaItems.Create(pMediaItems);
			if (FAILED(hRes))
			{
				_com_issue_error(hRes);
			}
		}
    }
    catch (_com_error &e)
    {
        hRes = e.Error();
    }
    return hRes;
}

HRESULT CMediaSetNode::Destroy() throw()
{
    // Delete items
    for (MediaSetNodeMap::iterator pos = m_Children.begin();
         pos != m_Children.end();
         pos ++)
    {
        if (pos->second != NULL)
        {
			pos->second->Destroy();
            delete pos->second;
            pos->second = NULL;
        }
    }
    m_Children.clear();

	if (m_pMediaSet != NULL)
    {
        m_pMediaSet.Release();
    }

	m_MediaItems.Destroy();
	m_pParent = NULL;

    return S_OK;
}

HRESULT CMediaSetNode::PrintInfo() throw()
{
    if (m_pMediaSet == NULL)
    {
        return E_INVALIDARG;
    }

    // Print info for this item
    try
    {
        tcout << _T("Media Set Index: ") << m_pMediaSet->GetIndex() << endl;
        wcout << L"Media Set Name: " << LPCWSTR(m_pMediaSet->GetName()) << endl;
        tcout << _T("Media Set Level: ") << m_pMediaSet->GetLevel() << endl;
        if (m_pParent != NULL)
        {
            tcout << _T("Media Set Parent: ") << m_pParent->m_pMediaSet->GetIndex() << endl;
        }
        else
        {
            tcout << _T("Media Set Parent: None") << endl;
        }
        tcout << _T("Media Set Children: ") << m_Children.size() << endl;
    }
    catch (_com_error &e)
    {
        return e.Error();
    }

    // Iterate through children
    HRESULT hRes = S_OK;
	for (MediaSetNodeMap::iterator pos = m_Children.begin();
         pos != m_Children.end();
         pos ++)
    {
        hRes = pos->second->PrintInfo();
        if (FAILED(hRes))
        {
            break;
        }
    }
    return hRes;
}

HRESULT CMediaSetNode::AddNodeNameKeyWord(LPCTSTR szParent) throw()
{
    if (m_pMediaSet == NULL)
    {
        return E_INVALIDARG;
    }

    try
    {
        // Get media set name, and remove invalid chars
        ATL::CStringW sName(LPCWSTR(m_pMediaSet->GetName()));
        sName.Replace(L";", L"_");

        // Build new keyword by appending node name
		ATL::CStringW sKeyWord(szParent);
		sKeyWord.Append(L"{");
        sKeyWord.Append(sName);
		sKeyWord.Append(L"}");

        // Add keyword to all images in this set
        HRESULT hRes = m_MediaItems.AddKeyWord(sKeyWord);
        if (FAILED(hRes))
        {
            return hRes;
        }

        // Iterate through children and add new keyword
		for (MediaSetNodeMap::iterator pos = m_Children.begin();
             pos != m_Children.end();
             pos ++)
        {
            hRes = pos->second->AddNodeNameKeyWord(sKeyWord);
            if (FAILED(hRes))
            {
                return hRes;
            }
        }
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    catch (ATL::CAtlException &e)
    {
        return e.m_hr;
    }
    return S_OK;
}


#pragma once

#include "MediaItemMap.h"

class CMediaSetNode
{
public:
    CMediaSetNode() throw();
    virtual ~CMediaSetNode() throw();

private:
    CMediaSetNode(const CMediaSetNode&) throw();
    CMediaSetNode& operator =(const CMediaSetNode&) throw();

public:
    HRESULT Create(IMediaSet *pMediaSet) throw();
    HRESULT Destroy() throw();
    HRESULT PrintInfo() throw();
	HRESULT AddNodeNameKeyWord(LPCTSTR szParent) throw();

public:
	typedef std::map<long, CMediaSetNode*> MediaSetNodeMap;

public:
    IMediaSetPtr m_pMediaSet;
    CMediaSetNode *m_pParent;
    MediaSetNodeMap m_Children;
	CMediaItemMap m_MediaItems;
};

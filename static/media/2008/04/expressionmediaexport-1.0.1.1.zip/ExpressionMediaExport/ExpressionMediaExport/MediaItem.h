#pragma once

class CMediaItem
{
public:
    CMediaItem() throw();
    virtual ~CMediaItem() throw();

private:
    CMediaItem(const CMediaItem&) throw();
    CMediaItem& operator =(const CMediaItem&) throw();

public:
	typedef std::vector<ATL::CStringW> StringVector;

public:
    HRESULT Create(IMediaItem *pMediaItem) throw();
    HRESULT Destroy() throw();
    HRESULT PrintInfo() throw();
	HRESULT AddKeyWord(LPCTSTR szKeyWord) throw();
	HRESULT AddKeyWords(const StringVector& KeyWords) throw();
	HRESULT GetKeyWords(StringVector& KeyWords) throw();
	HRESULT SetKeyWords(const StringVector& KeyWords) throw();
	HRESULT GetPeople(StringVector& People) throw();

public:
    IMediaItemPtr m_pMediaItem;

protected:
	void StringToVector(LPCTSTR szString, StringVector& Vector) throw(...);
	void VectorToString(const StringVector& Vector, ATL::CStringW& sString) throw(...);
};

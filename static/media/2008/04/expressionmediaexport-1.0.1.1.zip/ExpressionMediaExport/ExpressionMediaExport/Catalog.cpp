#include "StdAfx.h"

#include "Catalog.h"

using namespace std;

CCatalog::CCatalog() throw()
{
}

CCatalog::~CCatalog() throw()
{
    Destroy();
}

HRESULT CCatalog::Open(IApplication *pApplication, LPCTSTR szFileName) throw()
{
	if (pApplication == NULL)
	{
		return E_INVALIDARG;
	}

	Destroy();

    try
    {
        // Open the catalog file
		// Expression Media: Fails with RPC_S_SERVER_UNAVAILABLE
		// Media Pro: Fails with RPC_E_SERVERFAULT
        m_pCatalog = pApplication->Open(szFileName);
        if (m_pCatalog == NULL)
        {
            return E_FAIL;
        }
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    return S_OK;
}

HRESULT CCatalog::Attach(IApplication *pApplication) throw()
{
	if (pApplication == NULL)
	{
		return E_INVALIDARG;
	}

	Destroy();

	try
    {
        // Attach to active catalog
		m_pCatalog = pApplication->GetActiveCatalog();
        if (m_pCatalog == NULL)
        {
            return E_FAIL;
        }

		// Make sure that the catalog is an actual file and not the default empty catalog
		// Media Pro: If there is no catalog loaded this fails with RPC_E_SERVERFAULT
		_bstr_t sPath(m_pCatalog->GetPath());
		if (sPath.length() == 0)
		{
            return E_FAIL;
		}
    }
    catch (_com_error &e)
    {
        return e.Error();
    }
    return S_OK;
}

HRESULT CCatalog::Create() throw()
{
    if (m_pCatalog == NULL)
    {
        return E_INVALIDARG;
    }

	HRESULT hRes(S_OK);
    try
    {
		// Load media set tree
		hRes = m_MediaSetTree.Create(m_pCatalog);
		if (FAILED(hRes))
		{
			_com_issue_error(hRes);
		}

		// Load media items
		IMediaItemsPtr pMediaItems(m_pCatalog->GetMediaItems());
		if (pMediaItems != NULL)
		{
			hRes = m_MediaItems.Create(pMediaItems);
			if (FAILED(hRes))
			{
				_com_issue_error(hRes);
			}
		}
    }
    catch (_com_error &e)
    {
        hRes = e.Error();
    }
	return hRes;
}

HRESULT CCatalog::Destroy() throw()
{
	m_MediaSetTree.Destroy();
	m_MediaItems.Destroy();

	if (m_pCatalog != NULL)
    {
        m_pCatalog.Release();
    }

    return S_OK;
}

HRESULT CCatalog::PrintInfo() throw()
{
    if (m_pCatalog == NULL)
    {
        return E_INVALIDARG;
    }

    // Print catalog info
	try
    {
        tcout << _T("Catalog Index: ") << m_pCatalog->GetIndex() << endl;
        wcout << L"Catalog Name: " << LPCWSTR(m_pCatalog->GetName()) << endl;
        wcout << L"Catalog Path: " << LPCWSTR(m_pCatalog->GetPath()) << endl;
		tcout << _T("Image Count: ") << m_MediaItems.m_MediaItems.size() << endl;
    }
    catch (_com_error &e)
    {
        return e.Error();
    }

	// Print child info
	HRESULT hRes(S_OK);
	hRes = m_MediaSetTree.PrintInfo();
	if (FAILED(hRes))
	{
		return hRes;
	}
	hRes = m_MediaItems.PrintInfo();

    return hRes;
}

HRESULT CCatalog::AddMetaInfoToKeyWords() throw()
{
	// Add media set name to keywords using tree tructure
	HRESULT hRes(S_OK);
	hRes = m_MediaSetTree.AddNodeNameKeyWord();
	if (FAILED(hRes))
	{
		return hRes;
	}

	// Add people to keywords
	hRes = m_MediaItems.AddPeopleKeyWord();
	if (FAILED(hRes))
	{
		return hRes;
	}
	return S_OK;
}